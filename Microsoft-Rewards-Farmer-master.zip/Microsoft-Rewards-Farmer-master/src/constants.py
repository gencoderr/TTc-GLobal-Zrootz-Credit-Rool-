BASE_URL = "https://rewards.bing.com"
VERSION = 3.0
