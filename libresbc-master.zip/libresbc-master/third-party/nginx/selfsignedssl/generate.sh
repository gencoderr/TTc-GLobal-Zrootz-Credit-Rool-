openssl req -x509 -nodes -days 2190 -newkey rsa:2048 -keyout /etc/nginx/selfsignedssl/private.key -out /etc/nginx/selfsignedssl/fullchain.crt
