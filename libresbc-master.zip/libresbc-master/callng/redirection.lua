--
-- callng:redirection.lua
--
-- The Initial Developer of the Original Code is
-- Minh Minh <hnimminh at[@] outlook dot[.] com>
-- Portions created by the Initial Developer are Copyright (C) the Initial Developer.
-- All Rights Reserved.
--

require("callng.configuration")
log.info("module=callng, space=redirection, action=report, notice=please file a feature request for manual handle sip redirection")
