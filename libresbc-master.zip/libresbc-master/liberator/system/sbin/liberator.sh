#!/bin/sh
cd {{dstdir}}/liberator
/usr/bin/python3 {{dstdir}}/liberator/main.py &
